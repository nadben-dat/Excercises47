public class Main {
    public static void main(String[] args) {
        Library library = new Library();

        Book book1 = new Book("978-1-909227-85-9","Dracula",2014);
        library.addBook(book1);
        library.addBook("234-1-65670-792-2","Morder",2019);
        System.out.println("True search: "+library.searchByISBN("234-1-65970-792-2"));
        System.out.println("False search: "+library.searchByISBN("234-1-65670-792-2"));
        //view library
        System.out.println("\nView library:\n");
        library.viewBooks();
    }
}
