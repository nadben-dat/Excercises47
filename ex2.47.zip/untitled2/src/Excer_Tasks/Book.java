package Excer_Tasks;

public class Book {
    private String iSBN;
    private String title;
    private int yearOfPublication;


    public Book(String iSBN, String title,int yearOfPublication) {

       this.iSBN = iSBN;
       this.title = title;
        this.yearOfPublication= yearOfPublication;

    }
    public String getISBN() {
        return iSBN;
    }

    public void setISBN(String iSBN) {
        this.iSBN = iSBN;
    }

    public String gettitle() {
        return  title;
    }

    public void settitle(String title) {
        this.title = title;
    }

    public int getYearOfPublication() {
        return yearOfPublication;
    }

    public void setYearOfPublication(int yearOfPublication) {
        this.yearOfPublication = yearOfPublication;
    }

    @Override
    public String toString() {
        return "Book{" +
                "iSBN='" + iSBN + '\'' +
                ", title='" + title + '\'' +
                ", yearOfPublication=" + yearOfPublication +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Book)) return false;
        Book book = (Book) o;
        return iSBN.equals(book.iSBN);
    }


    }
}

