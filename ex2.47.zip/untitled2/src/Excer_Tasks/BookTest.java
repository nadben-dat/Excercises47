package Excer_Tasks;

import static org.junit.jupiter.api.Assertions.*;

class BookTest {

    @org.junit.jupiter.api.Test
    void getISBN() {
    }

    @org.junit.jupiter.api.Test
    void setISBN() {
    }

    @org.junit.jupiter.api.Test
    void gettitle() {
    }

    @org.junit.jupiter.api.Test
    void settitle() {
    }

    @org.junit.jupiter.api.Test
    void getYearOfPublication() {
    }

    @org.junit.jupiter.api.Test
    void setYearOfPublication() {
    }

    @org.junit.jupiter.api.Test
    void testToString() {
    }

    @org.junit.jupiter.api.Test
    void testEquals() {
    }
}