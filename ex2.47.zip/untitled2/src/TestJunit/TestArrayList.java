package TestJunit;

import org.junit.Test;
import java.util.ArrayList;
import java.util.Collections;


public class TestArrayList {

    private static ArrayList<String> stringList;
    private static String Bobi;
    ArrayList<String> StringList = new ArrayList<>();

    //checks that it isn't null
    //if string isn't within the arrayList, adds string and returns "true"
    //sorts the array
    public static boolean stringArrayMethod(ArrayList<String> arrayList, String string) {
        if (!arrayList.contains(string) && string != null) {
            arrayList.add(string);
            Collections.sort(arrayList);
            return true;
            Collections.sort(arrayList);
            return false;
        }

        @Test

            stringArrayMethod(stringList, "Bobi");
            assertEquals(stringList.get(stringList.size() - 1), Bobi);
        }


       @Test
        public void testCorrectInput(){

                stringArrayMethod(stringList, "Jo");
        assertEquals(stringList.get(stringList.size() - 1), "Jo");
        }

        @Test
        public void testDuplicateInput () {
            stringArrayMethod(stringList, "Bobi");
            assertFalse(stringArrayMethod(stringList, "Bobi"));
        }

        @Test
        public void testNullInput () {
            stringArrayMethod(stringList, null);
            assertFalse(stringArrayMethod(stringList, null));
        }
    }

    private static void assertFalse(boolean stringArrayMethod) {
    }

    private static void assertEquals(String s, String bobi) {
    }
}