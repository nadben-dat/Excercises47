import java.awt.print.Book;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Library {
    private List<Book> libraryList = new ArrayList<>();

    public void viewBooks(){
        libraryList.sort(new SortByTitle());
        for (Book book : libraryList) {
            System.out.println(book.toString());
            System.out.println(""); //spacer
        }
    }


class SortByTitle implements Comparator<Book> {
    @Override
    public int compare(Book a, Book b) {
        return a.getTitle().compareTo(b.getTitle());
    }
}