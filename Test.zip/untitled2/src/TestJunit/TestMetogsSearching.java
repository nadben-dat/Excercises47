package TestJunit;
import org.junit.Test;
import static org.junit.Assert.*;

public class Test {
    //Searching task

    public static int searchingMethod(String[] list, String s){
        for (int i = 0; i < list.length; i++) {
            if(list[i].equals(s)){
                return i;
            }
        }
        return -1;
    }

    String[] list = {"\"Cassandra","Mia","Albert","Ole"};

    @Test
    public void testA(){
        assertEquals(2,searchingMethod(list, "Cassandra"));
    }

    @Test
    public void testB(){
        assertEquals(3,searchingMethod(list, "Mia"));
    }

    @Test
    public void testC(){
        assertEquals(0,searchingMethod(list, "Albert"));
    }

    @Test
    public void testFailedSearch(){
        assertEquals(-1,searchingMethod(list, "Ole"));
    }
}